/**
 * GUI GAME - Snakes and Ladders- An interactive two-player game
 *
 * Vidhi Pandya
 * 
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;

public class snakesandladders extends JPanel implements ActionListener{
    //global variables
    //set all JPanels
    JPanel main = new JPanel ();
    JPanel game = new JPanel();
    JPanel instructions = new JPanel();
    JPanel options = new JPanel();
    JPanel grid = new JPanel ();
    JPanel score = new JPanel(new BorderLayout ());
    
    //use CardLayout to switch between screens
    CardLayout screens = new CardLayout ();
    
    //set player 1 and player 2 square values on the grid and set previous values as well to 0
    int p1 = 0;
    int p1_prev = 0;
    int p2 = 0;
    int p2_prev = 0 ;

    //set JLabel to store picture of snakes + ladders in the code
    JLabel backgroundgame = new JLabel("");

    //add JLabels for the grid
    JLabel g1, g2, g3, g4, g5, g6, g7, g8, g9 , g10, g11, g12, g13, g14, g15, g16, g17, g18, g19 , g20, g21, g22, g23, g24, g25, g26, g27, g28, g29, g30, g31, 
    g32, g33, g34, g35, g36, g37, g38, g39 , g40, g41, g42, g43, g44, g45, g46, g47, g48, g49 , g50, g51, g52, g53, g54, g55, g56, g57, g58, g59 , g60, g61, g62, 
    g63, g64, g65, g66, g67, g68, g69 , g70, g71, g72,g73, g74, g75, g76, g77, g78, g79 , g80, g81, g82, g83, g84, g85, g86, g87, g88, g89 , g90, g91, g92, g93,
    g94, g95, g96, g97, g98, g99 , g100;
    
    //variables for password and username
    JPanel passwordu = new JPanel ();
    JPasswordField p;
    JTextField u;
    public static void main (String []args)
    {
        snakesandladders content = new snakesandladders ();

        JFrame window = new JFrame ("Snakes and Ladders GUI Game");

        window.setContentPane( content);
        window.setSize(800,600);
        window.setLocation(100, 100);
        window.setVisible(true);

        
    }

    //screens
    public snakesandladders(){
        setLayout (screens);
        PasswordUser();
        mainscreen();
        gamescreen();
        optionsscreen();
        instructionsscreen();
    }//end constructor

    public void PasswordUser () {
        passwordu = new JPanel ();
        
        //add background image
        JLabel background1 = new JLabel("");
        background1.setIcon(new ImageIcon("backgroundmainscreen.png"));
        background1.setBounds(0, 0, 800, 600); 
        background1.setLayout (new FlowLayout ());
        passwordu.add (background1);
        
        //JLabel and Textfields for username and password
        JLabel name = new JLabel ("Username:");
        JLabel pass = new JLabel ("Password:");
        u = new JTextField (5);
        p = new JPasswordField (5);
        
        //username
        Panel username = new Panel();
        username.setBackground (Color.pink);
        username.add (name);
        username.add (u);
        background1.add (username);
        
        //password
        Panel password = new Panel();
        password.setBackground (Color.blue);
        password.add (pass);
        password.add (p);
        background1.add (password);
        
        //user clicks on JButton to enter
        JButton done = new JButton ("Done");
        done.setActionCommand ("Done");
        done.addActionListener(this);
        background1.add (done);
        
        add ("password", passwordu);
    }
    public void mainscreen()
    {
        main = new JPanel (new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();

        //add background picture on to the main screen
        JLabel background1 = new JLabel("");
        background1.setIcon(new ImageIcon("backgroundmainscreen.png"));
        background1.setBounds(0, 0, 800, 600); 
        background1.setLayout (new FlowLayout ());
        background1.setLayout (new GridBagLayout());

        //add widget
        main.add(background1);

        //add button to proceed to game
        JButton play = new JButton ("Play Snakes And Ladders");
        play.setFont (new Font("Century Gothic",Font.BOLD, 25));
        play.setBackground (Color.blue);
        play.setForeground (Color.white);
        play.setActionCommand("play");
        play.addActionListener(this);

        //use GridBagLayout to layout buttons
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.CENTER;
        c.gridx = 2;
        c.gridy = 2;
        c.gridwidth = 1;
        c.gridheight = 1;
        c.insets = new Insets(10,0,0,0);
        background1.add(play, c);

        //add button to proceed to the options screen
        JButton options = new JButton ("Options");
        options.setFont (new Font("Arial",Font.BOLD, 25));
        options.setBackground (Color.blue);
        options.setForeground (Color.white);
        options.setActionCommand("options");
        options.addActionListener(this);

        //use GridBagLayout to layout the button location
        c.anchor = GridBagConstraints.CENTER;
        c.gridx = 2;
        c.gridy = 4;
        c.gridwidth = 1;
        c.gridheight = 1;
        background1.add(options, c);

        //add button to proceed to the options screen
        JButton instructions = new JButton ("Instructions");
        instructions.setFont (new Font("Arial",Font.BOLD, 25));
        instructions.setBackground (Color.blue);
        instructions.setForeground (Color.white);
        instructions.setActionCommand("instructions");
        instructions.addActionListener(this);

        //use GridBagLayout to layout the button location
        c.anchor = GridBagConstraints.CENTER;
        c.gridx = 2;
        c.gridy = 3;
        c.gridwidth = 1;
        c.gridheight = 1;
        background1.add(instructions, c);

        //cardlayout - "1" represents the first page
        add ("1", main);
    }

    public void gamescreen()
    {
        //whole JPanel 
        game = new JPanel(new BorderLayout());
        game.setSize(800, 600); 

        //create a 10x10 grid to the Panel
        grid = new JPanel (new GridLayout(10,10));

        //add picture of snakes and ladders through JLabel
        backgroundgame = new JLabel("");
        backgroundgame.setIcon(new ImageIcon("salfinal.png"));
        backgroundgame.setBounds(0, 0, 800, 600); 
        //picture can go over the grid
        backgroundgame.setLayout (new FlowLayout ());

        game.add(backgroundgame);

        //set all JLabels and add to the grid
        g1 = new JLabel ("100");
        g2 = new JLabel ("99");
        g3 = new JLabel ("98");
        g4 = new JLabel ("97");
        g5 = new JLabel ("96");
        g6 = new JLabel ("95");
        g7 = new JLabel ("94");
        g8 = new JLabel ("93");
        g9 = new JLabel ("92");
        g10 = new JLabel ("91");
        g11 = new JLabel ("90");
        g12 = new JLabel ("89");
        g13 = new JLabel ("88");
        g14 = new JLabel ("87");
        g15 = new JLabel ("86");
        g16 = new JLabel ("85");
        g17 = new JLabel ("84");
        g18 = new JLabel ("83");
        g19 = new JLabel ("82");
        g20 = new JLabel ("81");
        g21 = new JLabel ("80");
        g22 = new JLabel ("79");
        g23 = new JLabel ("78");
        g24 = new JLabel ("77");
        g25 = new JLabel ("76");
        g26 = new JLabel ("75");
        g27 = new JLabel ("74");
        g28 = new JLabel ("73");
        g29 = new JLabel ("72");
        g30 = new JLabel ("71");
        g31 = new JLabel ("70");
        g32 = new JLabel ("69");
        g33 = new JLabel ("68");
        g34 = new JLabel ("67");
        g35 = new JLabel ("66");
        g36 = new JLabel ("65");
        g37 = new JLabel ("64");
        g38 = new JLabel ("63");
        g39 = new JLabel ("62");
        g40 = new JLabel ("61");
        g41 = new JLabel ("60");
        g42 = new JLabel ("59");
        g43 = new JLabel ("58");
        g44 = new JLabel ("57");
        g45 = new JLabel ("56");
        g46 = new JLabel ("55");
        g47 = new JLabel ("54");
        g48 = new JLabel ("53");
        g49 = new JLabel ("52");
        g50 = new JLabel ("51");
        g51 = new JLabel ("50");
        g52 = new JLabel ("49");
        g53 = new JLabel ("48");
        g54 = new JLabel ("47");
        g55 = new JLabel ("46");
        g56 = new JLabel ("45");
        g57 = new JLabel ("44");
        g58 = new JLabel ("43");
        g59 = new JLabel ("42");
        g60 = new JLabel ("41");
        g61 = new JLabel ("40");
        g62 = new JLabel ("39");
        g63 = new JLabel ("38");
        g64 = new JLabel ("37");
        g65 = new JLabel ("36");
        g66 = new JLabel ("35");
        g67 = new JLabel ("34");
        g68 = new JLabel ("33");
        g69 = new JLabel ("32");
        g70 = new JLabel ("31");
        g71 = new JLabel ("30");
        g72 = new JLabel ("29");
        g73 = new JLabel ("28");
        g74 = new JLabel ("27");
        g75 = new JLabel ("26");
        g76 = new JLabel ("25");
        g77 = new JLabel ("24");
        g78 = new JLabel ("23");
        g79 = new JLabel ("22");
        g80 = new JLabel ("21");
        g81 = new JLabel ("20");
        g82 = new JLabel ("19");
        g83 = new JLabel ("18");
        g84 = new JLabel ("17");
        g85 = new JLabel ("16");
        g86 = new JLabel ("15");
        g87 = new JLabel ("14");
        g88 = new JLabel ("13");
        g89 = new JLabel ("12");
        g90 = new JLabel ("11");
        g91 = new JLabel ("10");
        g92 = new JLabel ("9");
        g93 = new JLabel ("8");
        g94 = new JLabel ("7");
        g95 = new JLabel ("6");
        g96 = new JLabel ("5");
        g97 = new JLabel ("4");
        g98 = new JLabel ("3");
        g99 = new JLabel ("2");
        g100 = new JLabel ("1");

        grid.add (g1);
        grid.add (g2);
        grid.add (g3);
        grid.add (g4);
        grid.add (g5);
        grid.add (g6);
        grid.add (g7);
        grid.add (g8);
        grid.add (g9);
        grid.add (g10);
        grid.add (g11);
        grid.add (g12);
        grid.add (g13);
        grid.add (g14);
        grid.add (g15);
        grid.add (g16);
        grid.add (g17);
        grid.add (g18);
        grid.add (g19);
        grid.add (g20);
        grid.add (g21);
        grid.add (g22);
        grid.add (g23);
        grid.add (g24);
        grid.add (g25);
        grid.add (g26);
        grid.add (g27);
        grid.add (g28);
        grid.add (g29);
        grid.add (g30);
        grid.add (g31);
        grid.add (g32);
        grid.add (g33);
        grid.add (g34);
        grid.add (g35);
        grid.add (g36);
        grid.add (g37);
        grid.add (g38);
        grid.add (g39);
        grid.add (g40);
        grid.add (g41);
        grid.add (g42);
        grid.add (g43);
        grid.add (g44);
        grid.add (g45);
        grid.add (g46);
        grid.add (g47);
        grid.add (g48);
        grid.add (g49);
        grid.add (g50);
        grid.add (g51);
        grid.add (g52);
        grid.add (g53);
        grid.add (g54);
        grid.add (g55);
        grid.add (g56);
        grid.add (g57);
        grid.add (g58);
        grid.add (g59);
        grid.add (g60);
        grid.add (g61);
        grid.add (g62);
        grid.add (g63);
        grid.add (g64);
        grid.add (g65);
        grid.add (g66);
        grid.add (g67);
        grid.add (g68);
        grid.add (g69);
        grid.add (g70);
        grid.add (g71);
        grid.add (g72);
        grid.add (g73);
        grid.add (g74);
        grid.add (g75);
        grid.add (g76);
        grid.add (g77);
        grid.add (g78);
        grid.add (g79);
        grid.add (g80);
        grid.add (g81);
        grid.add (g82);
        grid.add (g83);
        grid.add (g84);
        grid.add (g85);
        grid.add (g86);
        grid.add (g87);
        grid.add (g88);
        grid.add (g89);
        grid.add (g90);
        grid.add (g91);
        grid.add (g92);
        grid.add (g93);
        grid.add (g94);
        grid.add (g95);
        grid.add (g96);
        grid.add (g97);
        grid.add (g98);
        grid.add (g99);
        grid.add (g100);

        
        grid.setBackground (Color.blue);
        //add grid to the left side of the whole jpanel
        game.add (grid, BorderLayout.CENTER);

        score = new JPanel(new BorderLayout ());
        score.setBackground (new Color (255,253,208));
        //add grid to the left side of the whole jpanel
        game.add (score, BorderLayout.EAST);

        //layout the panel on the right that allows each player to roll the dice
        score.setLayout (new GridBagLayout());
        options = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        
        //shows the player their roll button with a jlabel named "player 1"
        JLabel player1 = new JLabel ("Player 1");
        //indicates the colour of the player
        player1.setForeground (new Color(255,51,51));
        player1.setFont (new Font("Century Gothic",Font.BOLD, 25));
        g.anchor = GridBagConstraints.CENTER;
        g.gridx = 2;
        g.gridy = 0;
        g.gridwidth = 1;
        g.gridheight = 1;
        g.insets = new Insets(0,0,50,60);
        score.add(player1, g);

        //roll button for first player
        JButton roll1 = new JButton ("Roll");
        roll1.setActionCommand ("roll1");
        roll1.addActionListener (this);
        g.anchor = GridBagConstraints.CENTER;
        g.gridx = 3;
        g.gridy = 0;
        g.gridwidth = 1;
        g.gridheight = 1;
        g.insets = new Insets(0,0,50,60);
        score.add (roll1,g);

        //shows the player their roll button with a jlabel named "player 2"
        JLabel player2 = new JLabel ("Player 2");
        //indicates the colour of the player
        player2.setForeground(new Color (0,204,170));
        player2.setFont (new Font("Century Gothic",Font.BOLD, 25));
        g.anchor = GridBagConstraints.CENTER;
        g.gridx = 2;
        g.gridy = 1;
        g.gridwidth = 1;
        g.gridheight = 1;
        g.insets = new Insets(0,0,50,60);
        score.add (player2, g);

        //roll button for second player
        JButton roll2 = new JButton ("Roll");
        roll2.setActionCommand ("roll2");
        roll2.addActionListener (this);
        g.anchor = GridBagConstraints.CENTER;
        g.gridx = 3;
        g.gridy = 1;
        g.gridwidth = 1;
        g.gridheight = 1;
        g.insets = new Insets(0,0,50,60);
        score.add (roll2,g);

        //add button to exit mainscreen
        JButton exit = new JButton ("Return to Main Menu");
        exit.setActionCommand ("exit");
        exit.addActionListener (this);
        g.anchor = GridBagConstraints.CENTER;
        g.gridx = 2;
        g.gridy = 100;
        g.gridwidth = 1;
        g.gridheight = 1;
        g.insets = new Insets(0,50,50,50);
        score.add(exit,g);


        //cardlayout to indicate this is the second screen
        add ("2", game);
    }

    public void optionsscreen()
    {
        //add options JPanel 
        options = new JPanel(new GridBagLayout());
        GridBagConstraints d = new GridBagConstraints();
        options.setPreferredSize(new Dimension(800,600));

        //sets x and y to 10 so it is easier to place components within the jpanel
        d.gridx = 10;
        d.gridy = 10;

        options.setBackground (Color.blue);
        
        //adds button to allow user to exit to main menu
        JButton exit2 = new JButton ("Return to Main Menu");
        exit2.setActionCommand ("exit2");
        exit2.addActionListener (this);
        options.add (exit2);

        //add title for Jpanel
        JLabel optionstitle = new JLabel ("OPTIONS");
        optionstitle.setFont (new Font("Century Gothic",Font.BOLD, 45));
        d.gridx = 2;
        d.gridy = 1;
        d.gridwidth = 1;
        d.gridheight = 1;
        options.add (optionstitle,d);

        //add title to display that the user has an option to change the background colours
        JLabel bc = new JLabel ("Background Colours");
        bc.setFont (new Font ("Century Gothic", Font.BOLD, 30));        
        d.gridx = 2;
        d.gridy = 2;
        d.gridwidth = 1;
        d.gridheight = 1;
        options.add (bc,d);

        //Jbutton to change background colour to green
        JButton green = new JButton ("Green");
        green.setBackground (new Color(152,255,152));
        green.setForeground (Color.black);
        green.setActionCommand ("green");
        green.addActionListener (this);
        d.gridx = 0;
        d.gridy = 3;
        d.gridwidth = 1;
        d.gridheight = 1;
        d.insets = new Insets(0,10,0,10);
        options.add (green,d);

        //Jbutton to change background colour to purple
        JButton purple = new JButton ("Purple");
        purple.setBackground (new Color(177,156,217));
        purple.setForeground (Color.black);
        purple.setActionCommand ("purple");
        purple.addActionListener (this);
        d.gridx = 1;
        d.gridy = 3;
        d.gridwidth = 1;
        d.gridheight = 1;
        d.insets = new Insets(0,10,0,10);
        options.add (purple,d);

        //Jbutton to change background colour to yellow
        JButton yellow = new JButton ("Yellow");
        yellow.setBackground (new Color(253,253,150));
        yellow.setForeground (Color.black);
        yellow.setActionCommand ("yellow");
        yellow.addActionListener (this);
        d.gridx = 2;
        d.gridy = 3;
        d.gridwidth = 1;
        d.gridheight = 1;
        d.insets = new Insets(0,10,0,10);
        options.add (yellow,d);

        //Jbutton to change background colour to pink
        JButton pink = new JButton ("Pink");
        pink.setBackground (new Color(255,209,220));
        pink.setForeground (Color.black);
        pink.setActionCommand ("pink");
        pink.addActionListener (this);
        d.gridx = 3;
        d.gridy = 3;
        d.gridwidth = 1;
        d.gridheight = 1;
        d.insets = new Insets(0,10,0,10);
        options.add (pink,d);

        //Jbutton to change background colour to orange
        JButton peach = new JButton ("Orange");
        peach.setBackground (new Color(255,229,180));
        peach.setForeground (Color.black);
        peach.setActionCommand ("orange");
        peach.addActionListener (this);
        d.gridx = 4;
        d.gridy = 3;
        d.gridwidth = 1;
        d.gridheight = 1;
        options.add (peach,d);

        

        //cardlayout - "3" indicates this is screen three
        add ("3", options);
    }

    public void instructionsscreen()
    {
        //new Jpanel
        instructions = new JPanel(new GridBagLayout());
        GridBagConstraints r = new GridBagConstraints();

        //use gridconstraints of 5x5 to place objects within the Jpanel
        r.gridx = 5;
        r.gridy = 5;

        //add title on the top
        JLabel ititle = new JLabel ("Instructions");
        ititle.setForeground (Color.pink);
        ititle.setFont (new Font ("Century Gothic", Font.BOLD, 40));
        r.gridx = 3;
        r.gridy = 0;
        r.gridwidth = 1;
        r.gridheight = 1;
        instructions.add (ititle,r);

        //add instructions - they are short and simple as the game is not complicated
        JLabel ins = new JLabel ("IT'S EASY!! JUST TAKE TURNS ROLLING THE DICE!!");
        ins.setFont (new Font ("Century Gothic", Font.BOLD, 25));
        ins.setForeground (new Color (0,204,170));
        r.gridx = 3;
        r.gridy = 2;
        r.gridwidth = 1;
        r.gridheight = 1;
        instructions.add (ins,r);

        JLabel ins2 = new JLabel ("FIRST PERSON TO REACH 100 WINS!!");
        ins2.setFont (new Font ("Century Gothic", Font.BOLD, 25));
        ins2.setForeground (new Color (0,204,170));
        r.gridx = 3;
        r.gridy = 3;
        r.gridwidth = 1;
        r.gridheight = 1;
        instructions.add (ins2,r);

        instructions.setBackground (Color.blue);
        
        //add button to exit to the main menu
        JButton exit3 = new JButton ("Return to Main Menu");
        exit3.setActionCommand ("exit3");
        exit3.addActionListener (this);
        r.gridx = 4;
        r.gridy = 4;
        r.gridwidth = 1;
        r.gridheight = 1;
        instructions.add (exit3,r);

        //card layout to indicate that this is screen 4
        add ("4", instructions);
    }

    public void actionPerformed (ActionEvent e){
        //the user must enter the correct password to enter
        if (e.getActionCommand().equals ("Done"))
        {
            if (u.getText().equals ("player")
            && Arrays.equals("sal123".toCharArray(), p.getPassword()))
            {
                screens.show (this, "1");
            }
            else 
            {
                JOptionPane.showMessageDialog (passwordu, "Incorrect Password");
            }
        }
        //if the user wishes to move between screens, the action command will proceed to allow them to
        if (e.getActionCommand().equals ("play"))
        {
            screens.show (this, "2");
        }
        if (e.getActionCommand().equals ("exit"))
        {
            screens.show (this, "1");
        }
        if (e.getActionCommand().equals ("instructions"))
        {
            screens.show (this, "4");
        }
        if (e.getActionCommand().equals ("options"))
        {
            screens.show (this, "3");
        }
        if (e.getActionCommand().equals ("exit2"))
        {
            screens.show (this, "1");
        }
        if (e.getActionCommand().equals ("exit3"))
        {
            screens.show (this, "1");
        }

        //set the background of each screen to the according colour when the user wishes to 
        if (e.getActionCommand().equals ("green"))
        {
            score.setBackground (new Color(152,255,152));
            options.setBackground (new Color(152,255,152));
            instructions.setBackground (new Color(152,255,152));
        }
        if (e.getActionCommand().equals ("purple"))
        {
            score.setBackground (new Color(177,156,217));
            options.setBackground (new Color(177,156,217));
            instructions.setBackground (new Color(177,156,217));
        }
        if (e.getActionCommand().equals ("yellow"))
        {
            score.setBackground (new Color(253,253,150));
            options.setBackground (new Color(253,253,150));
            instructions.setBackground (new Color(253,253,150));
        }
        if (e.getActionCommand().equals ("pink"))
        {
            score.setBackground (new Color(255,209,220));
            options.setBackground (new Color(255,209,220));
            instructions.setBackground (new Color(255,209,220));
        }
        if (e.getActionCommand().equals ("orange"))
        {
            score.setBackground (new Color(255,229,180));
            options.setBackground (new Color(255,229,180));
            instructions.setBackground (new Color(255,229,180));
        }

        //when the first player rolls their dice
        if (e.getActionCommand().equals ("roll1"))
        {
            //creates a random number 
            int dice = (int) (Math.random () * 6 + 1);
            //stores previous value in order to change to black after new value has been create
            p1_prev = p1;
            //new value of square
            p1=p1+dice;
        }

        //checks each value and changes value to red for player 1 
        if (p1 == 1)
        {
            g100.setForeground (new Color(255,51,51));
        }
        if (p1 == 2)
        {
            g99.setForeground (new Color(255,51,51));
        }
        if (p1 == 3)
        {
            g98.setForeground (new Color(255,51,51));
        }
        if (p1 == 4)
        {
            g97.setForeground (new Color(255,51,51));
        }
        if (p1 == 5)
        {
            g96.setForeground (new Color(255,51,51));
        }
        if (p1 == 6)
        {
            g95.setForeground (new Color(255,51,51));
        }
        //a ladder!! changes value of square above ladder 
        if (p1 == 7)
        {
            g56.setForeground (new Color(255,51,51));
            p1=45;
        }
        if (p1 == 8)
        {
            g93.setForeground (new Color(255,51,51));
        }
        if (p1 == 9)
        {
            g92.setForeground (new Color(255,51,51));
        }
        if (p1 == 10)
        {
            g91.setForeground (new Color(255,51,51));
        }
        if (p1 == 11)
        {
            g90.setForeground (new Color(255,51,51));
        }
        if (p1 == 12)
        {
            g89.setForeground (new Color(255,51,51));
        }
        if (p1 == 13)
        {
            g88.setForeground (new Color(255,51,51));
        }
        if (p1 == 14)
        {
            g87.setForeground (new Color(255,51,51));
        }
        if (p1 == 15)
        {
            g86.setForeground (new Color(255,51,51));
        }
        if (p1 == 16)
        {
            g85.setForeground (new Color(255,51,51));
        }
        if (p1 == 17)
        {
            g84.setForeground (new Color(255,51,51));
        }
        if (p1 == 18)
        {
            g83.setForeground (new Color(255,51,51));
        }
        if (p1 == 19)
        {
            g82.setForeground (new Color(255,51,51));
        }
        if (p1 == 20)
        {
            g81.setForeground (new Color(255,51,51));
        }
        if (p1 == 21)
        {
            g80.setForeground (new Color(255,51,51));
        }
        if (p1 == 22)
        {
            g79.setForeground (new Color(255,51,51));
        }
        if (p1 == 23)
        {
            g78.setForeground (new Color(255,51,51));
        }
        if (p1 == 24)
        {
            g77.setForeground (new Color(255,51,51));
        }
        if (p1 == 25)
        {
            g76.setForeground (new Color(255,51,51));
        }
        if (p1 == 26)
        {
            g75.setForeground (new Color(255,51,51));
        }
        if (p1 == 27)
        {
            g74.setForeground (new Color(255,51,51));
        }
        if (p1 == 28)
        {
            g73.setForeground (new Color(255,51,51));
        }
        if (p1 == 29)
        {
            g72.setForeground (new Color(255,51,51));
        }
        if (p1 == 30)
        {
            g71.setForeground (new Color(255,51,51));
        }
        if (p1 == 31)
        {
            g70.setForeground (new Color(255,51,51));
        }
        if (p1 == 32)
        {
            g69.setForeground (new Color(255,51,51));
        }
        if (p1 == 33)
        {
            g68.setForeground (new Color(255,51,51));
        }
        if (p1 == 34)
        {
            g67.setForeground (new Color(255,51,51));
        }
        if (p1 == 35)
        {
            g66.setForeground (new Color(255,51,51));
        }
        if (p1 == 36)
        {
            g65.setForeground (new Color(255,51,51));
        }
        if (p1 == 37)
        {
            g64.setForeground (new Color(255,51,51));
        }
        if (p1 == 38)
        {
            g63.setForeground (new Color(255,51,51));
        }
        if (p1 == 39)
        {
            g62.setForeground (new Color(255,51,51));
        }
        if (p1 == 40)
        {
            g61.setForeground (new Color(255,51,51));
        }
        if (p1 == 41)
        {
            g60.setForeground (new Color(255,51,51));
        }
        if (p1 == 42)
        {
            g59.setForeground (new Color(255,51,51));
        }

        if (p1 == 43)
        {
            g58.setForeground (new Color(255,51,51));
        }
        if (p1 == 44)
        {
            g57.setForeground (new Color(255,51,51));
        }
        if (p1 == 45)
        {
            g56.setForeground (new Color(255,51,51));
        }
        if (p1 == 46)
        {
            g55.setForeground (new Color(255,51,51));
        }
         //a ladder!! changes value of square above ladder
        if (p1 == 47)
        {
            g23.setForeground (new Color(255,51,51));
            p1=78;
        }
        if (p1 == 48)
        {
            g53.setForeground (new Color(255,51,51));
        }
        if (p1 == 49)
        {
            g52.setForeground (new Color(255,51,51));
        }
        if (p1 == 50)
        {
            g51.setForeground (new Color(255,51,51));
        }
         //a snake!! changes value of square under snake
        if (p1 == 51)
        {
            g78.setForeground (new Color(255,51,51));
            p1=23;
        }
         //a ladder!! changes value of square above ladder
        if (p1 == 52)
        {
            g18.setForeground (new Color(255,51,51));
            p1=83;
        }
        if (p1 == 53)
        {
            g48.setForeground (new Color(255,51,51));
        }
        if (p1 == 54)
        {
            g47.setForeground (new Color(255,51,51));
        }
        if (p1 == 55)
        {
            g46.setForeground (new Color(255,51,51));
        }
        if (p1 == 56)
        {
            g45.setForeground (new Color(255,51,51));
        }
         //a snake!! changes value of square under snake
        if (p1 == 57)
        {
            g62.setForeground (new Color(255,51,51));
            p1=39;
        }
        if (p1 == 58)
        {
            g43.setForeground (new Color(255,51,51));
        }
        if (p1 == 59)
        {
            g42.setForeground (new Color(255,51,51));
        }
        if (p1 == 60)
        {
            g41.setForeground (new Color(255,51,51));
        }
        if (p1 == 61)
        {
            g40.setForeground (new Color(255,51,51));
        }
        if (p1 == 62)
        {
            g39.setForeground (new Color(255,51,51));
        }
        if (p1 == 63)
        {
            g38.setForeground (new Color(255,51,51));
        }
        if (p1 == 64)
        {
            g37.setForeground (new Color(255,51,51));
        }
        if (p1 == 65)
        {
            g36.setForeground (new Color(255,51,51));
        }
        if (p1 == 66)
        {
            g35.setForeground (new Color(255,51,51));
        }
        if (p1 == 67)
        {
            g34.setForeground (new Color(255,51,51));
        }
        if (p1 == 68)
        {
            g33.setForeground (new Color(255,51,51));
        }
        if (p1 == 69)
        {
            g32.setForeground (new Color(255,51,51));
        }
        if (p1 == 70)
        {
            g31.setForeground (new Color(255,51,51));
        }
        if (p1 == 71)
        {
            g30.setForeground (new Color(255,51,51));
        }
        if (p1 == 72)
        {
            g29.setForeground (new Color(255,51,51));
        }
        if (p1 == 73)
        {
            g28.setForeground (new Color(255,51,51));
        }
        if (p1 == 74)
        {
            g27.setForeground (new Color(255,51,51));
        }
        if (p1 == 75)
        {
            g26.setForeground (new Color(255,51,51));
        }
        if (p1 == 76)
        {
            g25.setForeground (new Color(255,51,51));
        }
        if (p1 == 77)
        {
            g24.setForeground (new Color(255,51,51));
        }
        if (p1 == 78)
        {
            g23.setForeground (new Color(255,51,51));
        }
        if (p1 == 79)
        {
            g22.setForeground (new Color(255,51,51));
        }
        if (p1 == 80)
        {
            g21.setForeground (new Color(255,51,51));
        }
        if (p1 == 81)
        {
            g20.setForeground (new Color(255,51,51));
        }
        if (p1 == 82)
        {
            g19.setForeground (new Color(255,51,51));
        }
        if (p1 == 83)
        {
            g18.setForeground (new Color(255,51,51));
        }
        if (p1 == 84)
        {
            g17.setForeground (new Color(255,51,51));
        }
        if (p1 == 85)
        {
            g16.setForeground (new Color(255,51,51));
        }
        if (p1 == 86)
        {
            g15.setForeground (new Color(255,51,51));
        }
         //a snake!! changes value of square under snake
        if (p1 == 87)
        {
            g90.setForeground (new Color(255,51,51));
            p1=11;
        }
        if (p1 == 88)
        {
            g13.setForeground (new Color(255,51,51));
        }
        if (p1 == 89)
        {
            g12.setForeground (new Color(255,51,51));
        }
        if (p1 == 90)
        {
            g11.setForeground (new Color(255,51,51));
        }
        if (p1 == 91)
        {
            g10.setForeground (new Color(255,51,51));
        }
        if (p1 == 92)
        {
            g9.setForeground (new Color(255,51,51));
        }

        if (p1 == 93)
        {
            g8.setForeground (new Color(255,51,51));
        }
        if (p1 == 94)
        {
            g7.setForeground (new Color(255,51,51));
        }
        if (p1 == 95)
        {
            g6.setForeground (new Color(255,51,51));
        }
        if (p1 == 96)
        {
            g5.setForeground (new Color(255,51,51));
        }
        if (p1 == 97)
        {
            g4.setForeground (new Color(255,51,51));
        }
        if (p1 == 98)
        {
            g3.setForeground (new Color(255,51,51));
        }
        if (p1 == 99)
        {
            g2.setForeground (new Color(255,51,51));
        }
        if (p1 == 100 || p1>=100)
        {
            g1.setForeground (new Color(255,51,51));
            JOptionPane.showMessageDialog(game, "Player 1 Wins!! Exit the screen.");
        }

        //set previous value to black again
        if (p1_prev == 1)
        {
            g100.setForeground (Color.black);
        }
        if (p1_prev == 2)
        {
            g99.setForeground (Color.black);
        }
        if (p1_prev == 3)
        {
            g98.setForeground (Color.black);
        }
        if (p1_prev == 4)
        {
            g97.setForeground (Color.black);
        }
        if (p1_prev == 5)
        {
            g96.setForeground (Color.black);
        }
        if (p1_prev == 6)
        {
            g95.setForeground (Color.black);
        }
        if (p1_prev == 7)
        {
            g94.setForeground (Color.black);
        }
        if (p1_prev == 8)
        {
            g93.setForeground (Color.black);
        }
        if (p1_prev == 9)
        {
            g92.setForeground (Color.black);
        }
        if (p1_prev == 10)
        {
            g91.setForeground (Color.black);
        }
        if (p1_prev == 11)
        {
            g90.setForeground (Color.black);
        }
        if (p1_prev == 12)
        {
            g89.setForeground (Color.black);
        }
        if (p1_prev == 13)
        {
            g88.setForeground (Color.black);
        }
        if (p1_prev == 14)
        {
            g87.setForeground (Color.black);
        }
        if (p1_prev == 15)
        {
            g86.setForeground (Color.black);
        }
        if (p1_prev == 16)
        {
            g85.setForeground (Color.black);
        }
        if (p1_prev == 17)
        {
            g84.setForeground (Color.black);
        }
        if (p1_prev == 18)
        {
            g83.setForeground (Color.black);
        }
        if (p1_prev == 19)
        {
            g82.setForeground (Color.black);
        }
        if (p1_prev == 20)
        {
            g81.setForeground (Color.black);
        }
        if (p1_prev == 21)
        {
            g80.setForeground (Color.black);
        }
        if (p1_prev == 22)
        {
            g79.setForeground (Color.black);
        }
        if (p1_prev == 23)
        {
            g78.setForeground (Color.black);
        }
        if (p1_prev == 24)
        {
            g77.setForeground (Color.black);
        }
        if (p1_prev == 25)
        {
            g76.setForeground (Color.black);
        }
        if (p1_prev == 26)
        {
            g75.setForeground (Color.black);
        }
        if (p1_prev == 27)
        {
            g74.setForeground (Color.black);
        }
        if (p1_prev == 28)
        {
            g73.setForeground (Color.black);
        }
        if (p1_prev == 29)
        {
            g72.setForeground (Color.black);
        }
        if (p1_prev == 30)
        {
            g71.setForeground (Color.black);
        }
        if (p1_prev == 31)
        {
            g70.setForeground (Color.black);
        }
        if (p1_prev == 32)
        {
            g69.setForeground (Color.black);
        }
        if (p1_prev == 33)
        {
            g68.setForeground (Color.black);
        }
        if (p1_prev == 34)
        {
            g67.setForeground (Color.black);
        }
        if (p1_prev == 35)
        {
            g66.setForeground (Color.black);
        }
        if (p1_prev == 36)
        {
            g65.setForeground (Color.black);
        }
        if (p1_prev == 37)
        {
            g64.setForeground (Color.black);
        }
        if (p1_prev == 38)
        {
            g63.setForeground (Color.black);
        }
        if (p1_prev == 39)
        {
            g62.setForeground (Color.black);
        }
        if (p1_prev == 40)
        {
            g61.setForeground (Color.black);
        }
        if (p1_prev == 41)
        {
            g60.setForeground (Color.black);
        }
        if (p1_prev == 42)
        {
            g59.setForeground (Color.black);
        }

        if (p1_prev == 43)
        {
            g58.setForeground (Color.black);
        }
        if (p1_prev == 44)
        {
            g57.setForeground (Color.black);
        }
        if (p1_prev == 45)
        {
            g56.setForeground (Color.black);
        }
        if (p1_prev == 46)
        {
            g55.setForeground (Color.black);
        }
        if (p1_prev == 47)
        {
            g54.setForeground (Color.black);
        }
        if (p1_prev == 48)
        {
            g53.setForeground (Color.black);
        }
        if (p1_prev == 49)
        {
            g52.setForeground (Color.black);
        }
        if (p1_prev == 50)
        {
            g51.setForeground (Color.black);
        }
        if (p1_prev == 51)
        {
            g50.setForeground (Color.black);
        }
        if (p1_prev == 52)
        {
            g49.setForeground (Color.black);
        }
        if (p1_prev == 53)
        {
            g48.setForeground (Color.black);
        }
        if (p1_prev == 54)
        {
            g47.setForeground (Color.black);
        }
        if (p1_prev == 55)
        {
            g46.setForeground (Color.black);
        }
        if (p1_prev == 56)
        {
            g45.setForeground (Color.black);
        }
        if (p1_prev == 57)
        {
            g44.setForeground (Color.black);
        }
        if (p1_prev == 58)
        {
            g43.setForeground (Color.black);
        }
        if (p1_prev == 59)
        {
            g42.setForeground (Color.black);
        }
        if (p1_prev == 60)
        {
            g41.setForeground (Color.black);
        }
        if (p1_prev == 61)
        {
            g40.setForeground (Color.black);
        }
        if (p1_prev == 62)
        {
            g39.setForeground (Color.black);
        }
        if (p1_prev == 63)
        {
            g38.setForeground (Color.black);
        }
        if (p1_prev == 64)
        {
            g37.setForeground (Color.black);
        }
        if (p1_prev == 65)
        {
            g36.setForeground (Color.black);
        }
        if (p1_prev == 66)
        {
            g35.setForeground (Color.black);
        }
        if (p1_prev == 67)
        {
            g34.setForeground (Color.black);
        }
        if (p1_prev == 68)
        {
            g33.setForeground (Color.black);
        }
        if (p1_prev == 69)
        {
            g32.setForeground (Color.black);
        }
        if (p1_prev == 70)
        {
            g31.setForeground (Color.black);
        }
        if (p1_prev == 71)
        {
            g30.setForeground (Color.black);
        }
        if (p1_prev == 72)
        {
            g29.setForeground (Color.black);
        }
        if (p1_prev == 73)
        {
            g28.setForeground (Color.black);
        }
        if (p1_prev == 74)
        {
            g27.setForeground (Color.black);
        }
        if (p1_prev == 75)
        {
            g26.setForeground (Color.black);
        }
        if (p1_prev == 76)
        {
            g25.setForeground (Color.black);
        }
        if (p1_prev == 77)
        {
            g24.setForeground (Color.black);
        }
        if (p1_prev == 78)
        {
            g23.setForeground (Color.black);
        }
        if (p1_prev == 79)
        {
            g22.setForeground (Color.black);
        }
        if (p1_prev == 80)
        {
            g21.setForeground (Color.black);
        }
        if (p1_prev == 81)
        {
            g20.setForeground (Color.black);
        }
        if (p1_prev == 82)
        {
            g19.setForeground (Color.black);
        }
        if (p1_prev == 83)
        {
            g18.setForeground (Color.black);
        }
        if (p1_prev == 84)
        {
            g17.setForeground (Color.black);
        }
        if (p1_prev == 85)
        {
            g16.setForeground (Color.black);
        }
        if (p1_prev == 86)
        {
            g15.setForeground (Color.black);
        }
        if (p1_prev == 87)
        {
            g14.setForeground (Color.black);
        }
        if (p1_prev == 88)
        {
            g13.setForeground (Color.black);
        }
        if (p1_prev == 89)
        {
            g12.setForeground (Color.black);
        }
        if (p1_prev == 90)
        {
            g11.setForeground (Color.black);
        }
        if (p1_prev == 91)
        {
            g10.setForeground (Color.black);
        }
        if (p1_prev == 92)
        {
            g9.setForeground (Color.black);
        }
        if (p1_prev == 93)
        {
            g8.setForeground (Color.black);
        }
        if (p1_prev == 94)
        {
            g7.setForeground (Color.black);
        }
        if (p1_prev == 95)
        {
            g6.setForeground (Color.black);
        }
        if (p1_prev == 96)
        {
            g5.setForeground (Color.black);
        }
        if (p1_prev == 97)
        {
            g4.setForeground (Color.black);
        }
        if (p1_prev == 98)
        {
            g3.setForeground (Color.black);
        }
        if (p1_prev == 99)
        {
            g2.setForeground (Color.black);
        }
        if (p1_prev == 100 || p1_prev>=100)
        {
            g1.setForeground (Color.black);
        }

        //if the second player rolls
        if (e.getActionCommand().equals ("roll2"))
        {
            //creates a random value (for the dice)
            int dice2 = (int) (Math.random () * 6 + 1);
            //stores the previous value
            p2_prev = p2;
            //the square number the player is on
            p2=p2+dice2;
        }

        //checks all values and changes the foreground colour to indicate the player's location
        if (p2 == 1)
        {
            g100.setForeground(new Color (0,204,170));
        }
        if (p2 == 2)
        {
            g99.setForeground(new Color (0,204,170));
        }
        if (p2 == 3)
        {
            g98.setForeground(new Color (0,204,170));
        }
        if (p2 == 4)
        {
            g97.setForeground(new Color (0,204,170));
        }
        if (p2 == 5)
        {
            g96.setForeground(new Color (0,204,170));
        }
        if (p2 == 6)
        {
            g95.setForeground(new Color (0,204,170));
        }
        //a ladder!! changes value of square above ladder 
        if (p2 == 7)
        {
            g56.setForeground(new Color (0,204,170));
            p2=45;
        }
        if (p2 == 8)
        {
            g93.setForeground(new Color (0,204,170));
        }
        if (p2 == 9)
        {
            g92.setForeground(new Color (0,204,170));
        }
        if (p2 == 10)
        {
            g91.setForeground(new Color (0,204,170));
        }
        if (p2 == 11)
        {
            g90.setForeground(new Color (0,204,170));
        }
        if (p2 == 12)
        {
            g89.setForeground(new Color (0,204,170));
        }
        if (p2 == 13)
        {
            g88.setForeground(new Color (0,204,170));
        }
        if (p2 == 14)
        {
            g87.setForeground(new Color (0,204,170));
        }
        if (p2 == 15)
        {
            g86.setForeground(new Color (0,204,170));
        }
        if (p2 == 16)
        {
            g85.setForeground(new Color (0,204,170));
        }
        if (p2 == 17)
        {
            g84.setForeground(new Color (0,204,170));
        }
        if (p2 == 18)
        {
            g83.setForeground(new Color (0,204,170));
        }
        if (p2 == 19)
        {
            g82.setForeground(new Color (0,204,170));
        }
        if (p2 == 20)
        {
            g81.setForeground(new Color (0,204,170));
        }
        if (p2 == 21)
        {
            g80.setForeground(new Color (0,204,170));
        }
        if (p2 == 22)
        {
            g79.setForeground(new Color (0,204,170));
        }
        if (p2 == 23)
        {
            g78.setForeground(new Color (0,204,170));
        }
        if (p2 == 24)
        {
            g77.setForeground(new Color (0,204,170));
        }
        if (p2 == 25)
        {
            g76.setForeground(new Color (0,204,170));
        }
        if (p2 == 26)
        {
            g75.setForeground(new Color (0,204,170));
        }
        if (p2 == 27)
        {
            g74.setForeground(new Color (0,204,170));
        }
        if (p2 == 28)
        {
            g73.setForeground(new Color (0,204,170));
        }
        if (p2 == 29)
        {
            g72.setForeground(new Color (0,204,170));
        }
        if (p2 == 30)
        {
            g71.setForeground(new Color (0,204,170));
        }
        if (p2 == 31)
        {
            g70.setForeground(new Color (0,204,170));
        }
        if (p2 == 32)
        {
            g69.setForeground(new Color (0,204,170));
        }
        if (p2 == 33)
        {
            g68.setForeground(new Color (0,204,170));
        }
        if (p2 == 34)
        {
            g67.setForeground(new Color (0,204,170));
        }
        if (p2 == 35)
        {
            g66.setForeground(new Color (0,204,170));
        }
        if (p2 == 36)
        {
            g65.setForeground(new Color (0,204,170));
        }
        if (p2 == 37)
        {
            g64.setForeground(new Color (0,204,170));
        }
        if (p2 == 38)
        {
            g63.setForeground(new Color (0,204,170));
        }
        if (p2 == 39)
        {
            g62.setForeground(new Color (0,204,170));
        }
        if (p2 == 40)
        {
            g61.setForeground(new Color (0,204,170));
        }
        if (p2 == 41)
        {
            g60.setForeground(new Color (0,204,170));
        }
        if (p2 == 42)
        {
            g59.setForeground(new Color (0,204,170));
        }
        if (p2 == 43)
        {
            g58.setForeground(new Color (0,204,170));
        }
        if (p2 == 44)
        {
            g57.setForeground(new Color (0,204,170));
        }
        if (p2 == 45)
        {
            g56.setForeground(new Color (0,204,170));
        }
        if (p2 == 46)
        {
            g55.setForeground(new Color (0,204,170));
        }
        //a ladder!! changes value of square above ladder 
        if (p2 == 47)
        {
            g23.setForeground(new Color (0,204,170));
            p2=78;
        }
        if (p2 == 48)
        {
            g53.setForeground(new Color (0,204,170));
        }
        if (p2 == 49)
        {
            g52.setForeground(new Color (0,204,170));
        }
        if (p2 == 50)
        {
            g51.setForeground(new Color (0,204,170));
        }
        //a snake!! changes value of square under snake
        if (p2 == 51)
        {
            g78.setForeground(new Color (0,204,170));
            p2=23;
        }
        //a ladder!! changes value of square above ladder 
        if (p2 == 52)
        {
            g18.setForeground(new Color (0,204,170));
            p2=83;
        }
        if (p2 == 53)
        {
            g48.setForeground(new Color (0,204,170));
        }
        if (p2 == 54)
        {
            g47.setForeground(new Color (0,204,170));
        }
        if (p2 == 55)
        {
            g46.setForeground(new Color (0,204,170));
        }
        if (p2 == 56)
        {
            g45.setForeground(new Color (0,204,170));
        }
        //a snake!! changes value of square under snake
        if (p2 == 57)
        {
            g62.setForeground(new Color (0,204,170));
            p2=39;
        }
        if (p2 == 58)
        {
            g43.setForeground(new Color (0,204,170));
        }
        if (p2 == 59)
        {
            g42.setForeground(new Color (0,204,170));
        }
        if (p2 == 60)
        {
            g41.setForeground(new Color (0,204,170));
        }
        if (p2 == 61)
        {
            g40.setForeground(new Color (0,204,170));
        }
        if (p2 == 62)
        {
            g39.setForeground(new Color (0,204,170));
        }
        if (p2 == 63)
        {
            g38.setForeground(new Color (0,204,170));
        }
        if (p2 == 64)
        {
            g37.setForeground(new Color (0,204,170));
        }
        if (p2 == 65)
        {
            g36.setForeground(new Color (0,204,170));
        }
        if (p2 == 66)
        {
            g35.setForeground(new Color (0,204,170));
        }
        if (p2 == 67)
        {
            g34.setForeground(new Color (0,204,170));
        }
        if (p2 == 68)
        {
            g33.setForeground(new Color (0,204,170));
        }
        if (p2 == 69)
        {
            g32.setForeground(new Color (0,204,170));
        }
        if (p2 == 70)
        {
            g31.setForeground(new Color (0,204,170));
        }
        if (p2 == 71)
        {
            g30.setForeground(new Color (0,204,170));
        }
        if (p2 == 72)
        {
            g29.setForeground(new Color (0,204,170));
        }
        if (p2 == 73)
        {
            g28.setForeground(new Color (0,204,170));
        }
        if (p2 == 74)
        {
            g27.setForeground(new Color (0,204,170));
        }
        if (p2 == 75)
        {
            g26.setForeground(new Color (0,204,170));
        }
        if (p2 == 76)
        {
            g25.setForeground(new Color (0,204,170));
        }
        if (p2 == 77)
        {
            g24.setForeground(new Color (0,204,170));
        }
        if (p2 == 78)
        {
            g23.setForeground(new Color (0,204,170));
        }
        if (p2 == 79)
        {
            g22.setForeground(new Color (0,204,170));
        }
        if (p2 == 80)
        {
            g21.setForeground(new Color (0,204,170));
        }
        if (p2 == 81)
        {
            g20.setForeground(new Color (0,204,170));
        }
        if (p2 == 82)
        {
            g19.setForeground(new Color (0,204,170));
        }
        if (p2 == 83)
        {
            g18.setForeground(new Color (0,204,170));
        }
        if (p2 == 84)
        {
            g17.setForeground(new Color (0,204,170));
        }
        if (p2 == 85)
        {
            g16.setForeground(new Color (0,204,170));
        }
        if (p2 == 86)
        {
            g15.setForeground(new Color (0,204,170));
        }
        //a snake!! changes value of square under snake
        if (p2 == 87)
        {
            g90.setForeground(new Color (0,204,170));
            p2=11;
        }
        if (p2 == 88)
        {
            g13.setForeground(new Color (0,204,170));
        }
        if (p2 == 89)
        {
            g12.setForeground(new Color (0,204,170));
        }
        if (p2 == 90)
        {
            g11.setForeground(new Color (0,204,170));
        }
        if (p2 == 91)
        {
            g10.setForeground(new Color (0,204,170));
        }
        if (p2 == 92)
        {
            g9.setForeground(new Color (0,204,170));
        }

        if (p2 == 93)
        {
            g8.setForeground(new Color (0,204,170));
        }
        if (p2 == 94)
        {
            g7.setForeground(new Color (0,204,170));
        }
        if (p2 == 95)
        {
            g6.setForeground(new Color (0,204,170));
        }
        if (p2 == 96)
        {
            g5.setForeground(new Color (0,204,170));
        }
        if (p2 == 97)
        {
            g4.setForeground(new Color (0,204,170));
        }
        if (p2 == 98)
        {
            g3.setForeground(new Color (0,204,170));
        }
        if (p2 == 99)
        {
            g2.setForeground(new Color (0,204,170));
        }
        if (p2 == 100 || p2>=100)
        {
            g1.setForeground(new Color (0,204,170));
            JOptionPane.showMessageDialog(game, "Player 2 Wins!! Exit the screen.");
        }

        //turns the previous value into black
        if (p2_prev == 1)
           {
               g100.setForeground (Color.black);
           }
        if (p2_prev == 2)
           {
               g99.setForeground (Color.black);
           }
if (p2_prev == 3)
           {
               g98.setForeground (Color.black);
           }
if (p2_prev == 4)
           {
               g97.setForeground (Color.black);
           }
if (p2_prev == 5)
           {
               g96.setForeground (Color.black);
           }
if (p2_prev == 6)
           {
               g95.setForeground (Color.black);
           }
if (p2_prev == 7)
           {
               g94.setForeground (Color.black);
           }
if (p2_prev == 8)
           {
               g93.setForeground (Color.black);
           }
if (p2_prev == 9)
           {
               g92.setForeground (Color.black);
           }
if (p2_prev == 10)
           {
               g91.setForeground (Color.black);
           }
if (p2_prev == 11)
           {
               g90.setForeground (Color.black);
           }
if (p2_prev == 12)
           {
               g89.setForeground (Color.black);
           }
if (p2_prev == 13)
           {
               g88.setForeground (Color.black);
           }
if (p2_prev == 14)
           {
               g87.setForeground (Color.black);
           }
if (p2_prev == 15)
           {
               g86.setForeground (Color.black);
           }
if (p2_prev == 16)
           {
               g85.setForeground (Color.black);
           }
if (p2_prev == 17)
           {
               g84.setForeground (Color.black);
           }
if (p2_prev == 18)
           {
               g83.setForeground (Color.black);
           }
if (p2_prev == 19)
           {
               g82.setForeground (Color.black);
           }
if (p2_prev == 20)
           {
               g81.setForeground (Color.black);
           }
if (p2_prev == 21)
           {
               g80.setForeground (Color.black);
           }
if (p2_prev == 22)
           {
               g79.setForeground (Color.black);
           }
if (p2_prev == 23)
           {
               g78.setForeground (Color.black);
           }
if (p2_prev == 24)
           {
               g77.setForeground (Color.black);
           }
if (p2_prev == 25)
           {
               g76.setForeground (Color.black);
           }
if (p2_prev == 26)
           {
               g75.setForeground (Color.black);
           }
if (p2_prev == 27)
           {
               g74.setForeground (Color.black);
           }
if (p2_prev == 28)
           {
               g73.setForeground (Color.black);
           }
if (p2_prev == 29)
           {
               g72.setForeground (Color.black);
           }
if (p2_prev == 30)
           {
               g71.setForeground (Color.black);
           }
if (p2_prev == 31)
           {
               g70.setForeground (Color.black);
           }
if (p2_prev == 32)
           {
               g69.setForeground (Color.black);
           }
if (p2_prev == 33)
           {
               g68.setForeground (Color.black);
           }
if (p2_prev == 34)
           {
               g67.setForeground (Color.black);
           }
if (p2_prev == 35)
           {
               g66.setForeground (Color.black);
           }
if (p2_prev == 36)
           {
               g65.setForeground (Color.black);
           }
if (p2_prev == 37)
           {
               g64.setForeground (Color.black);
           }
if (p2_prev == 38)
           {
               g63.setForeground (Color.black);
           }
if (p2_prev == 39)
           {
               g62.setForeground (Color.black);
           }
if (p2_prev == 40)
           {
               g61.setForeground (Color.black);
           }
if (p2_prev == 41)
           {
               g60.setForeground (Color.black);
           }
if (p2_prev == 42)
           {
               g59.setForeground (Color.black);
           }

if (p2_prev == 43)
           {
               g58.setForeground (Color.black);
           }
if (p2_prev == 44)
           {
               g57.setForeground (Color.black);
           }
if (p2_prev == 45)
           {
               g56.setForeground (Color.black);
           }
if (p2_prev == 46)
           {
               g55.setForeground (Color.black);
           }
if (p2_prev == 47)
           {
               g54.setForeground (Color.black);
           }
if (p2_prev == 48)
           {
               g53.setForeground (Color.black);
           }
if (p2_prev == 49)
           {
               g52.setForeground (Color.black);
           }
if (p2_prev == 50)
           {
               g51.setForeground (Color.black);
           }
if (p2_prev == 51)
           {
               g50.setForeground (Color.black);
           }
if (p2_prev == 52)
           {
               g49.setForeground (Color.black);
           }
if (p2_prev == 53)
           {
               g48.setForeground (Color.black);
           }
if (p2_prev == 54)
           {
               g47.setForeground (Color.black);
           }
if (p2_prev == 55)
           {
               g46.setForeground (Color.black);
           }
if (p2_prev == 56)
           {
               g45.setForeground (Color.black);
           }
if (p2_prev == 57)
           {
               g44.setForeground (Color.black);
           }
if (p2_prev == 58)
           {
               g43.setForeground (Color.black);
           }
if (p2_prev == 59)
           {
               g42.setForeground (Color.black);
           }
if (p2_prev == 60)
           {
               g41.setForeground (Color.black);
           }
if (p2_prev == 61)
           {
               g40.setForeground (Color.black);
           }
if (p2_prev == 62)
           {
               g39.setForeground (Color.black);
           }
if (p2_prev == 63)
           {
               g38.setForeground (Color.black);
           }
if (p2_prev == 64)
           {
               g37.setForeground (Color.black);
           }
if (p2_prev == 65)
           {
               g36.setForeground (Color.black);
           }
if (p2_prev == 66)
           {
               g35.setForeground (Color.black);
           }
if (p2_prev == 67)
           {
               g34.setForeground (Color.black);
           }
if (p2_prev == 68)
           {
               g33.setForeground (Color.black);
           }
if (p2_prev == 69)
           {
               g32.setForeground (Color.black);
           }
if (p2_prev == 70)
           {
               g31.setForeground (Color.black);
           }
if (p2_prev == 71)
           {
               g30.setForeground (Color.black);
           }
if (p2_prev == 72)
           {
               g29.setForeground (Color.black);
           }
if (p2_prev == 73)
           {
               g28.setForeground (Color.black);
           }
if (p2_prev == 74)
           {
               g27.setForeground (Color.black);
           }
if (p2_prev == 75)
           {
               g26.setForeground (Color.black);
           }
if (p2_prev == 76)
           {
               g25.setForeground (Color.black);
           }
if (p2_prev == 77)
           {
               g24.setForeground (Color.black);
           }
if (p2_prev == 78)
           {
               g23.setForeground (Color.black);
           }
if (p2_prev == 79)
           {
               g22.setForeground (Color.black);
           }
if (p2_prev == 80)
           {
               g21.setForeground (Color.black);
           }
if (p2_prev == 81)
           {
               g20.setForeground (Color.black);
           }
if (p2_prev == 82)
           {
               g19.setForeground (Color.black);
           }
if (p2_prev == 83)
           {
               g18.setForeground (Color.black);
           }
if (p2_prev == 84)
           {
               g17.setForeground (Color.black);
           }
if (p2_prev == 85)
           {
               g16.setForeground (Color.black);
           }
if (p2_prev == 86)
           {
               g15.setForeground (Color.black);
           }
if (p2_prev == 87)
           {
               g14.setForeground (Color.black);
           }
if (p2_prev == 88)
           {
               g13.setForeground (Color.black);
           }
if (p2_prev == 89)
           {
               g12.setForeground (Color.black);
           }
if (p2_prev == 90)
           {
               g11.setForeground (Color.black);
           }
if (p2_prev == 91)
           {
               g10.setForeground (Color.black);
           }
if (p2_prev == 92)
           {
               g9.setForeground (Color.black);
           }

if (p2_prev == 93)
           {
               g8.setForeground (Color.black);
           }
if (p2_prev == 94)
           {
               g7.setForeground (Color.black);
           }
if (p2_prev == 95)
           {
               g6.setForeground (Color.black);
           }
if (p2_prev == 96)
           {
               g5.setForeground (Color.black);
           }
if (p2_prev == 97)
           {
               g4.setForeground (Color.black);
           }
if (p2_prev == 98)
           {
               g3.setForeground (Color.black);
           }
if (p2_prev == 99)
           {
               g2.setForeground (Color.black);
           }
if (p2_prev == 100 || p2_prev>=100)
           {
               g1.setForeground (Color.black);
           }

    }

    protected static ImageIcon createImageIcon (String path)
    {
        java.net.URL imgURL = snakesandladders.class.getResource( path);
        if (imgURL != null){
            return new ImageIcon (imgURL);
        } else {
            System.err.println( "Couldn't find file: " + path);
            return null;
        }
    }
}